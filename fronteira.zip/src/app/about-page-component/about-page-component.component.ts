import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-page-component',
  templateUrl: './about-page-component.component.html',
  styleUrls: ['./about-page-component.component.css']
})
export class AboutPageComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
