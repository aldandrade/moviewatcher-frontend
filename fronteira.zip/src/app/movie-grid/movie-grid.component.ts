import { Component, OnInit } from '@angular/core';
import { MovieModel } from '../movie.model';

@Component({
  selector: 'app-movie-grid',
  templateUrl: './movie-grid.component.html',
  styleUrls: ['./movie-grid.component.css']
})
export class MovieGridComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
