import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-page-component',
  templateUrl: './error-page-component.component.html',
  styleUrls: ['./error-page-component.component.css']
})
export class ErrorPageComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
